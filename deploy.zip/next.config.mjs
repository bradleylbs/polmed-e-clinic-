/** @type {import('next').NextConfig} */
const nextConfig = {
  // Enable static export for Azure Static Web Apps
  output: 'export',
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  async redirects() {
    return [
      {
        source: '/',
        destination: '/landing',
        permanent: false,
      },
    ]
  },
  async rewrites() {
    // Allow the Next.js app to proxy API calls to the Flask backend
    // Configure backend URL via NEXT_PUBLIC_API_PROXY or default to localhost:5000
    const backend = process.env.NEXT_PUBLIC_API_PROXY || 'http://localhost:5000'
    return [
      {
        source: '/api/:path*',
        destination: `${backend}/api/:path*`,
      },
    ]
  },
}

export default nextConfig
